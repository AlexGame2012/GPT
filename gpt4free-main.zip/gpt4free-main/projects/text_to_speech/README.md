Fork from:

https://github.com/xenova/transformers.js/tree/main/examples/text-to-speech-client